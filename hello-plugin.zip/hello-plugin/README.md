# hello-plugin
Dummy Claude plugin: one skill (`say-hello`) and one command (`/hello`).
