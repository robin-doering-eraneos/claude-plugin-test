---
name: say-hello
description: Greets the user with a cheerful, personalised hello. Use when the user says "say hello" or asks for a greeting.
---

# Say Hello

Greet the user warmly by name (if known) in one or two sentences, then mention today's date.
