---
description: Print a friendly hello message
---

Say hello to the user and confirm that the hello-plugin is installed and working.
